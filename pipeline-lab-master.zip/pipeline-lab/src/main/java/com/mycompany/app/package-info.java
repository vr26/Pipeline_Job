/**
 * Jenkins Pipeline sample Java source code.
 *
 * See https://github.com/cloudbees/training-pipeline-sample/
 */
