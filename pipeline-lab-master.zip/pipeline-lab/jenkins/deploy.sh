#!/usr/bin/env bash

env

echo "Deploying: $1"
